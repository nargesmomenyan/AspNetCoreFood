using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OdeoFood.Data;

namespace OdeoFood.Pages.Restaurant
{
    public class DeleteModel : PageModel
    {
        private readonly IRestaurantData restaurantData;
        private OdeoFood.Core.Restaurant restaurant;

        public DeleteModel(IRestaurantData restaurantData)
        {
            this.restaurantData = restaurantData;
        }

        public IActionResult OnGet(int restaurantId)
        {
            restaurant = restaurantData.GetRestaurant(restaurantId);
            if (restaurant == null)
                return RedirectToPage("./NotFound");

            return Page();
        }

        public IActionResult OnPost(int restaurantId)
        {
            restaurant = restaurantData.GetRestaurant(restaurantId);
            if (restaurant == null)
                return RedirectToPage("./NotFound");

            restaurant = restaurantData.Delete(restaurantId);
            TempData["Message"] = $"restaurant {restaurant.Name} was deleted!";
            return RedirectToPage("./List");
        }
    }
}
