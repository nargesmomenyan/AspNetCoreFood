using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using OdeoFood.Data;

namespace OdeoFood.Pages.Restaurant
{
    public class ListModel : PageModel
    {
        public string MessageFromAppSetting { get; set; }

        [TempData]
        public string Message { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public IEnumerable<Core.Restaurant> RestaurantList { get; set; }
        public ListModel(IConfiguration config, IRestaurantData restaurantData)
        {
            Config = config;
            RestaurantData = restaurantData;
        }

        public IConfiguration Config { get; }
        public IRestaurantData RestaurantData { get; }

        public void OnGet()
        {
            var qs = HttpContext.Request.QueryString;
            this.MessageFromAppSetting = Config["Message"];
            RestaurantList = RestaurantData.GetRestaurantsByName();
        }
    }
}
