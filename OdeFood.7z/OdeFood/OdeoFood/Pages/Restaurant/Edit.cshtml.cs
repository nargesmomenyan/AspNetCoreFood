using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OdeoFood.Data;

namespace OdeoFood.Pages.Restaurant
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public OdeoFood.Core.Restaurant Restaurant { get; set; }
        public IEnumerable<SelectListItem> Cuisines { get; set; }
        public IRestaurantData RestaurantData { get; }
        public IHtmlHelper HtmlHelper { get; }

        public EditModel(IRestaurantData restaurantData, IHtmlHelper htmlHelper)
        {
            RestaurantData = restaurantData;
            HtmlHelper = htmlHelper;
        }

        public IActionResult OnGet(int? restaurantId)
        {
            Cuisines = HtmlHelper.GetEnumSelectList<Core.CuisineType>();
            if (restaurantId.HasValue)
                Restaurant = RestaurantData.GetRestaurant(restaurantId.Value);
            else
                Restaurant = new Core.Restaurant();

            if (Restaurant == null)
                return RedirectToPage("./NotFound");
            return Page();
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Restaurant.Id == 0)
                {
                    RestaurantData.Add(Restaurant);
                }
                else
                {
                    RestaurantData.Update(Restaurant);
                }
                RestaurantData.Commit();
                TempData["Message"] = "Restaurant was saved successfully";
                return RedirectToPage("./Detail", new { restaurantId = Restaurant.Id });
            }
            Cuisines = HtmlHelper.GetEnumSelectList<Core.CuisineType>();
            return Page();
        }

    }
}
