﻿using OdeoFood.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OdeoFood.Data
{
    public class InMemoryRestaurantData : IRestaurantData
    {
        readonly List<Restaurant> restaurants;

        public InMemoryRestaurantData()
        {
            restaurants = new List<Restaurant>
            {
                new Restaurant{Id=1, Name="McDonald", Cuisine= CuisineType.Mexican, Location="Pars Avenue"},
                new Restaurant{Id=10, Name="Salar", Cuisine= CuisineType.Italian, Location="Salar Avenue"},
            };
        }

        public Restaurant Add(Restaurant restaurant)
        {
            restaurant.Id = restaurants.Max(restaurant => restaurant.Id) + 1;
            restaurants.Add(restaurant);
            return restaurant;
        }

        public int Commit()
        {
            return 0;
        }

        public Restaurant Delete(int id)
        {
            var restaurant = restaurants.FirstOrDefault(item => item.Id == id);
            if (restaurant != null)
                restaurants.Remove(restaurant);
            return restaurant;
        }

        public Restaurant GetRestaurant(int id)
        {
            return restaurants.FirstOrDefault(item => item.Id == id);
        }

        public IEnumerable<Restaurant> GetRestaurantsByName(string name = null)
        {
            var list = from i in restaurants
                       where string.IsNullOrWhiteSpace(name) || i.Name.Contains(name, StringComparison.OrdinalIgnoreCase)
                       select i;

            return list;
        }

        public Restaurant Update(Restaurant restaurant)
        {
            var restauratForUpdate = restaurants.FirstOrDefault(r => r.Id == restaurant.Id);
            if (restauratForUpdate != null)
            {
                restauratForUpdate.Name = restaurant.Name;
                restauratForUpdate.Location = restaurant.Location;
                restauratForUpdate.Cuisine = restaurant.Cuisine;
            }
            return restaurant;
        }
    }
}
