﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace OdeoFood.Data
{
    public class OdeoFoodDbContext :DbContext
    {
        public OdeoFoodDbContext(DbContextOptions<OdeoFoodDbContext> options)
            :base(options)
        {
        }
        public DbSet<Core.Restaurant> Restaurants { get; set; }
    }
}
