﻿using OdeoFood.Core;
using System.Collections.Generic;
using System.Text;

namespace OdeoFood.Data
{
    public interface IRestaurantData
    {
        IEnumerable<Restaurant> GetRestaurantsByName(string name = null);
        Restaurant GetRestaurant(int id);

        Restaurant Update(Restaurant restaurant);
        Restaurant Add(Restaurant restaurant);

        Restaurant Delete(int id);

        int Commit();
    }
}
