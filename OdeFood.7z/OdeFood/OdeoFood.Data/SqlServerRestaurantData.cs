﻿using OdeoFood.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OdeoFood.Data
{
    public class SqlRestaurantData : IRestaurantData
    {
        public SqlRestaurantData(OdeoFoodDbContext db)
        {
            Db = db;
        }

        public OdeoFoodDbContext Db { get; }

        public Restaurant Add(Restaurant restaurant)
        {
            Db.Add(restaurant);
            return restaurant;
        }

        public int Commit()
        {
            return Db.SaveChanges();
        }

        public Restaurant Delete(int id)
        {
            var restaurant = GetRestaurant(id);
            if (restaurant != null)
                Db.Restaurants.Remove(restaurant);
            return restaurant;
        }

        public Restaurant GetRestaurant(int id)
        {
            return Db.Restaurants.Find(id);
        }

        public IEnumerable<Restaurant> GetRestaurantsByName(string name = null)
        {
            var query = from x
                        in Db.Restaurants
                        where x.Name.Contains(name) || string.IsNullOrWhiteSpace(name)
                        orderby x.Name
                        select x;
            return query;
        }

        public Restaurant Update(Restaurant restaurant)
        {
            var entity = Db.Restaurants.Attach(restaurant);
            entity.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return restaurant;
        }
    }
}
