﻿namespace OdeoFood.Core
{
    public enum CuisineType
    {
        None,
        Mexican,
        Italian,
        Japanese
    }
}
