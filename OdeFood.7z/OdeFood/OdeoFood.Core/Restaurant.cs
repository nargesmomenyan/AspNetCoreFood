﻿using System;
using System.ComponentModel.DataAnnotations;

namespace OdeoFood.Core
{
    public class Restaurant
    {
        public int Id { get; set; }

        [Required,MaxLength(80)]
        public string Name { get; set; }

        [Required, MaxLength(255)]
        public string Location { get; set; }

        [Required]
        public CuisineType Cuisine { get; set; }
    }
}
